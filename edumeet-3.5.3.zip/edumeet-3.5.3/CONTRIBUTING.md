Source code contributions should pass static code analysis as performed by `npm run lint` in `server` and `app` respectively.

Please contribute by creating your pull requests against the `develop` branch.
