#!/usr/bin/env node

const interactiveClient = require('./lib/interactive/Client');

interactiveClient();
