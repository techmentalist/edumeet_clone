# ![edumeet logo](/app/public/images/logo.edumeet.svg)
# Documentation / Table Of Contents
### [Overview eduMEET](/README.md)
### [Documentation of configuration for client/app](/app/public/config/README.md)
### [Documentation of configuration for server](/server/config/README.md)
### [Documentation of Development enviroment with Docker](/compose/README.md)
### [Setup HAproxy / load balancing edumeet](HAproxy.md)
### [Scaling and recommended Hardware](SCALING_AND_HARDWARE.md)
