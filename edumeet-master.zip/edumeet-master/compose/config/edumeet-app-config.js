// eslint-disable-next-line
var config =
{
	developmentPort : 8443,
	productionPort  : 3443
};
